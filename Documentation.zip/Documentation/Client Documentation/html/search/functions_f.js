var searchData=
[
  ['_7enoncopyable_288',['~NonCopyable',['../class_non_copyable.html#a143ae2a73c598b07b1c3dcbd22514027',1,'NonCopyable']]],
  ['_7enonmoveable_289',['~NonMoveable',['../class_non_moveable.html#a351e9a146fcacae313e6ffb9cdf33c66',1,'NonMoveable']]]
];
