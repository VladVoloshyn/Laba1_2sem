var indexSectionsWithContent =
{
  0: "acdefgilmnoprstuwxy~",
  1: "acglmnprs",
  2: "d",
  3: "aceglmnprs",
  4: "acdegilmnoprstw~",
  5: "mrsxy",
  6: "cs",
  7: "cdefglmnprsu",
  8: "s",
  9: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues",
  8: "related",
  9: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Enumerations",
  7: "Enumerator",
  8: "Friends",
  9: "Macros"
};

