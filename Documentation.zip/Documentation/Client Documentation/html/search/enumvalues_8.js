var searchData=
[
  ['playgame_352',['PlayGame',['../namespace_docking_1_1_client.html#a265cf2d36677179bc52467fe468e57afa2b72748a2883e2d950831bb0c0349259',1,'Docking::Client']]],
  ['position_353',['Position',['../namespace_docking_1_1_client.html#a90b7629b70623341ed27ca0e2e71ffbca52f5e0bc3859bc5f5e25130b6c7e8881',1,'Docking::Client']]]
];
