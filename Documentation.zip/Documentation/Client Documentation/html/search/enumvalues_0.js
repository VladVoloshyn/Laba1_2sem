var searchData=
[
  ['closedgame_338',['ClosedGame',['../namespace_docking_1_1_client.html#a90b7629b70623341ed27ca0e2e71ffbca89d5ca35e93e89c48de7b951233fe301',1,'Docking::Client']]],
  ['closedwindow_339',['ClosedWindow',['../namespace_docking_1_1_client.html#a90b7629b70623341ed27ca0e2e71ffbca8f64a1f7c236f9ce34fc3774d8d055d3',1,'Docking::Client']]],
  ['confirm_340',['Confirm',['../namespace_docking_1_1_client.html#aaf8192a7cb4b58e7abc4413b22ca32e1a70d9be9b139893aa6c69b5e77e614311',1,'Docking::Client']]]
];
