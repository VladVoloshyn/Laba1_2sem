var searchData=
[
  ['setposition_355',['SetPosition',['../namespace_docking_1_1_client.html#aaf8192a7cb4b58e7abc4413b22ca32e1a2730cd1ab1b090da09715097969af00c',1,'Docking::Client']]],
  ['startgame_356',['StartGame',['../namespace_docking_1_1_client.html#aaf8192a7cb4b58e7abc4413b22ca32e1a8a7b88cd602849e993a8ba3cdef39462',1,'Docking::Client']]]
];
