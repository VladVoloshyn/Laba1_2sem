var searchData=
[
  ['up_357',['Up',['../namespace_docking_1_1_client.html#a90b7629b70623341ed27ca0e2e71ffbca258f49887ef8d14ac268c92b02503aaa',1,'Docking::Client']]]
];
