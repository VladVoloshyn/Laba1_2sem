var searchData=
[
  ['testcase_1273',['TestCase',['../namespacedoctest_1_1detail.html#ade1619b532a3d3e6f19ee1187ff3c514',1,'doctest::detail']]]
];
