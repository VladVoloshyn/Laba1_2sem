var searchData=
[
  ['networkmanager_265',['NetworkManager',['../class_docking_1_1_client_1_1_network_manager.html#ac7342a285451eefcb85811f9bbdbba38',1,'Docking::Client::NetworkManager']]],
  ['noncopyable_266',['NonCopyable',['../class_non_copyable.html#a809b6e4ade7ae32f6d248f2a3b783d45',1,'NonCopyable::NonCopyable()=default'],['../class_non_copyable.html#a6f00fd0d70f055663114117ef8a12877',1,'NonCopyable::NonCopyable(const NonCopyable &amp;other)=delete']]],
  ['nonmoveable_267',['NonMoveable',['../class_non_moveable.html#abc3b2558d2dd6d578f828982fb9c408a',1,'NonMoveable::NonMoveable()=default'],['../class_non_moveable.html#a7b83c321a1ccb529f0fee3c85fe0883b',1,'NonMoveable::NonMoveable(NonMoveable &amp;&amp;other)=delete']]]
];
