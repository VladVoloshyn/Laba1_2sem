var searchData=
[
  ['red_1389',['Red',['../namespacedoctest_1_1_color.html#a32e9eaf6013139846e848af6e6cf2b92a67beb0a8d937993ad8b8cf6a238271f9',1,'doctest::Color']]],
  ['right_1390',['Right',['../namespace_docking_1_1_client.html#a90b7629b70623341ed27ca0e2e71ffbca92b09c7c48c520c3c55e497875da437c',1,'Docking::Client']]]
];
