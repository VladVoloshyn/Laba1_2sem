var searchData=
[
  ['s_5finstance_330',['s_Instance',['../class_singleton.html#add8f85db7cce71b4910be74504d668fe',1,'Singleton']]],
  ['singleton_3c_20menucontroller_20_3e_331',['Singleton&lt; MenuController &gt;',['../class_docking_1_1_client_1_1_menu_controller.html#ad87b8899bc117c4445b78491dc7823ca',1,'Docking::Client::MenuController']]],
  ['singleton_3c_20menurender_20_3e_332',['Singleton&lt; MenuRender &gt;',['../class_docking_1_1_client_1_1_menu_render.html#af06647a89a1c988c20fc15f243d5ed4a',1,'Docking::Client::MenuRender']]]
];
