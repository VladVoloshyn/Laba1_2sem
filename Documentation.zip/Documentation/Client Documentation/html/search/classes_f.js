var searchData=
[
  ['underlying_5ftype_926',['underlying_type',['../structdoctest_1_1detail_1_1underlying__type.html',1,'doctest::detail']]]
];
