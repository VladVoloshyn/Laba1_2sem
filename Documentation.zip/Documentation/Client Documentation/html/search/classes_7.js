var searchData=
[
  ['render_185',['Render',['../class_docking_1_1_client_1_1_render.html',1,'Docking::Client']]]
];
