var searchData=
[
  ['game_345',['Game',['../namespace_docking_1_1_client.html#a90b7629b70623341ed27ca0e2e71ffbca63d72051e901c069f8aa1b32aa0c43bb',1,'Docking::Client']]]
];
