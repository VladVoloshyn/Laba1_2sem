var searchData=
[
  ['findplayer_28',['FindPlayer',['../namespace_docking_1_1_client.html#a90b7629b70623341ed27ca0e2e71ffbcafd6855c2260d8c7466e61fb8fc654ecd',1,'Docking::Client']]]
];
