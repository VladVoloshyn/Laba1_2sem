var searchData=
[
  ['assets_170',['Assets',['../class_docking_1_1_client_1_1_assets.html',1,'Docking::Client']]]
];
