var searchData=
[
  ['player_270',['Player',['../class_docking_1_1_client_1_1_player.html#a2cae09b2d3c5365c2954995036b05a19',1,'Docking::Client::Player::Player()'],['../class_docking_1_1_client_1_1_player.html#a3b4cf2d079971375cda808bd209516d5',1,'Docking::Client::Player::Player(const std::string &amp;name, int wins)']]]
];
