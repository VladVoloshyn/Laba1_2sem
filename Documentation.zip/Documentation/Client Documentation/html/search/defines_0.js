var searchData=
[
  ['doctest_5fconfig_5fimplement_368',['DOCTEST_CONFIG_IMPLEMENT',['../main_8cpp.html#adf980eb1ed0df2191c56fd3d218c2819',1,'main.cpp']]]
];
