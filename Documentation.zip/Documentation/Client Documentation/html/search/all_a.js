var searchData=
[
  ['operator_3d_116',['operator=',['../class_non_copyable.html#a09b510381d825b0b283132f0a650b925',1,'NonCopyable::operator=()'],['../class_non_moveable.html#a39ae64f63fc09b27a43137c9ccf405eb',1,'NonMoveable::operator=()']]],
  ['operator_3d_3d_117',['operator==',['../namespace_docking_1_1_client.html#a3223fb0e08db932236333fde1e59a4b6',1,'Docking::Client']]]
];
