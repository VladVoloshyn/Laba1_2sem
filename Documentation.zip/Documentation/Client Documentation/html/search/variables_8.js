var searchData=
[
  ['is_5fcrash_1156',['is_crash',['../structdoctest_1_1_test_case_exception.html#af30d801dae6dd2f4ea01690bbf5faeca',1,'doctest::TestCaseException']]],
  ['is_5frunning_5fin_5ftest_1157',['is_running_in_test',['../namespacedoctest.html#a0b03060093b3894c976b6ae84e55f3f2',1,'doctest']]]
];
