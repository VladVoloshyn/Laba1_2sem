var searchData=
[
  ['leaderscontroller_259',['LeadersController',['../class_docking_1_1_client_1_1_leaders_controller.html#a76ef649c69c08a615cc6383442f3e1b7',1,'Docking::Client::LeadersController']]],
  ['leadersrender_260',['LeadersRender',['../class_docking_1_1_client_1_1_leaders_render.html#a1f4c29a8a1463b9650282fa5bff741c2',1,'Docking::Client::LeadersRender']]]
];
