var searchData=
[
  ['s_5finstance_1266',['s_Instance',['../class_singleton.html#add8f85db7cce71b4910be74504d668fe',1,'Singleton']]],
  ['seconds_1267',['seconds',['../structdoctest_1_1_current_test_case_stats.html#a29b1963f1d624d9f939f404726298f48',1,'doctest::CurrentTestCaseStats']]],
  ['singleton_3c_20menucontroller_20_3e_1268',['Singleton&lt; MenuController &gt;',['../class_docking_1_1_client_1_1_menu_controller.html#ad87b8899bc117c4445b78491dc7823ca',1,'Docking::Client::MenuController']]],
  ['singleton_3c_20menurender_20_3e_1269',['Singleton&lt; MenuRender &gt;',['../class_docking_1_1_client_1_1_menu_render.html#af06647a89a1c988c20fc15f243d5ed4a',1,'Docking::Client::MenuRender']]],
  ['size_1270',['size',['../structdoctest_1_1_string_1_1view.html#a41d7343e928b0e23c973521aac5b59d3',1,'doctest::String::view']]],
  ['subcase_5ffilter_5flevels_1271',['subcase_filter_levels',['../structdoctest_1_1_context_options.html#a93281aa958eed5c2a1533d404b1ebeff',1,'doctest::ContextOptions']]],
  ['success_1272',['success',['../structdoctest_1_1_context_options.html#a5c7bc4cf57fadf73e626666a0a548b92',1,'doctest::ContextOptions']]]
];
