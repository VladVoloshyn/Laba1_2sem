var searchData=
[
  ['player_118',['Player',['../class_docking_1_1_client_1_1_player.html',1,'Docking::Client::Player'],['../class_docking_1_1_client_1_1_player.html#a2cae09b2d3c5365c2954995036b05a19',1,'Docking::Client::Player::Player()'],['../class_docking_1_1_client_1_1_player.html#a3b4cf2d079971375cda808bd209516d5',1,'Docking::Client::Player::Player(const std::string &amp;name, int wins)']]],
  ['player_2ecpp_119',['Player.cpp',['../_player_8cpp.html',1,'']]],
  ['player_2eh_120',['Player.h',['../_player_8h.html',1,'']]],
  ['playgame_121',['PlayGame',['../namespace_docking_1_1_client.html#a265cf2d36677179bc52467fe468e57afa2b72748a2883e2d950831bb0c0349259',1,'Docking::Client']]],
  ['position_122',['Position',['../struct_docking_1_1_client_1_1_game_model_1_1_position.html',1,'Docking::Client::GameModel::Position'],['../namespace_docking_1_1_client.html#a90b7629b70623341ed27ca0e2e71ffbca52f5e0bc3859bc5f5e25130b6c7e8881',1,'Docking::Client::Position()']]]
];
