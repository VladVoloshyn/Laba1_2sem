var searchData=
[
  ['endgame_342',['EndGame',['../namespace_docking_1_1_client.html#aaf8192a7cb4b58e7abc4413b22ca32e1af0f29c4900d44c9e32d203ca799163e1',1,'Docking::Client']]],
  ['exit_343',['Exit',['../namespace_docking_1_1_client.html#a265cf2d36677179bc52467fe468e57afafef46e5063ce3dc78b8ae64fa474241d',1,'Docking::Client']]]
];
