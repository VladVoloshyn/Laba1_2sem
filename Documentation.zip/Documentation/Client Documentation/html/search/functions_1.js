var searchData=
[
  ['clientcontroller_239',['ClientController',['../class_docking_1_1_client_1_1_client_controller.html#a6b8e3d65a34b32e2796affe707a2d47d',1,'Docking::Client::ClientController']]],
  ['create_240',['Create',['../class_singleton.html#a6b73590ac8381016bf1012ab537ecfe9',1,'Singleton']]]
];
