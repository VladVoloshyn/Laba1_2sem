var searchData=
[
  ['clientcontroller_171',['ClientController',['../class_docking_1_1_client_1_1_client_controller.html',1,'Docking::Client']]],
  ['controller_172',['Controller',['../class_docking_1_1_client_1_1_controller.html',1,'Docking::Client']]]
];
